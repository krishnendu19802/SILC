import React from 'react'
import { Link, Navigate, useNavigate } from "react-router-dom"
import xyz from "../components/BookHall-logos.jpeg"
import img from "../components/backgroundimg.jpg"
export default function NewHomePage() {
//     document.body.style.backgroundImage=`url(${img})`
//     document.body.style.backgroundSize = "cover";
// document.body.style.backgroundPosition = "center";
const navigate=useNavigate()
const handleclick=()=>{
    navigate("/login")
}
    return (
        <div style={{backgroundColor: "rgba(0, 0, 0, 0.8)"}}>
            <nav class="navbar navbar-expand-lg bg-body-tertiary px-2">
                <div class="container-fluid">
                    <div className="d-flex">
                        <img src={xyz} alt="here" height={"50px"} width={"100px"} />
                        <a class="navbar-brand" href="#">Navbar</a>
                    </div>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                </div>
                <div className='ms-auto'>
                    <Link to="/addemployee">
                        <button className="btn btn-primary text-light">Click</button>
                    </Link>
                </div>
            </nav>

            <div>
                <button className="btn btn-success" onClick={handleclick}>Log In</button>
            </div>

        </div>
    )
}
