import React from 'react'
import Navbar from '../components/Navbar';
import { useParams } from 'react-router-dom';

export default function CurrentBookStats() {
    document.body.style.backgroundImage=""

    document.body.style.backgroundSize = "cover";
    document.body.style.backgroundPosition = "center";
    const params=useParams()
    // console.log(Object.keys(params))
    // console.log(params)
  return (
    <div>
      <Navbar display={true} card={"currentbookstatus"}/>
    </div>
  )
}
