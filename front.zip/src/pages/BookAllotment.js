import React from 'react'
import Navbar from '../components/Navbar'
import { useParams } from 'react-router-dom'

export default function BookAllotment() {
    document.body.style.backgroundImage=""

    document.body.style.backgroundSize = "cover";
    document.body.style.backgroundPosition = "center";

  return (
    <div>
      <Navbar display={true}  card={"bookallotment"}/>
    </div>
  )
}
