import React from 'react'
import Navbar from '../components/Navbar';

export default function NewBook() {
    document.body.style.backgroundImage=""

    document.body.style.backgroundSize = "cover";
    document.body.style.backgroundPosition = "center";
  return (
    <div>
     <Navbar display={true} card={"newbook"}/>
     
    </div>
  )
}
