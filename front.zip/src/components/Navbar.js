import React from 'react'
import xyz from "../components/BookHall-logos.jpeg"
import { Link, useParams } from 'react-router-dom'
export default function Navbar({display,card}) {
    // const params=useParams()
    function navigate(){
        if(display==true){
                let arr=[{type:"Statistics",id:"currentbookstatus"},{type:"Allotment",id:"bookallotment"},{type:"Return",id:"bookreturn"},{type:"New",id:"newbook"}]
                return (
                    <div className="d-flex ms-auto">
                       { arr.map((item)=>{
                        return (
                            <div className='text-light mx-3 fs-4'key={item.type}>
                                <Link to={`/${item.id}`}>
                                {item.type}
                            {card==item.id?<hr style={{border:"2px white solid"}}/>:""}
                            </Link>
                            </div>
                        )
                    }
                )}
                    </div>
                )
        }
        return ""
    }
    return (
        <div style={{backgroundColor: "rgba(0, 0, 0, 0.5)"}}>
            <nav className="navbar  navbar-expand-lg " style={{background:'transparent'}}>
                <div className="container-fluid ">
                    <div className="d-flex ">
                        <img src={xyz} alt="here" height={"50px"} width={"50px"} />
                        <Link class="navbar-brand fs-2 text-light mx-2" to="/">Navbar</Link>
                    </div>

                    {/* <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button> */}
                    {navigate()}
                    <button className="btn btn-danger text-light ms-auto">Log Out</button>

                </div>
            </nav>
        </div>
    )
}
