import React from 'react'
import xyz from "../components/BookHall-logos.jpeg"
import Navbar from './Navbar'
import img from "../components/backgroundimg.jpg"
import { Link } from 'react-router-dom'

export default function Mainpage() {
    const dispcards = [{
        title: "Current Book Statistics",
        url:"currentbookstatus"
    }, {
        title: "Book Allotment",
        url:"bookallotment"

    }, {
        title: "Book Return",
        url:"bookreturn"

    }, {
        title: "Add New Book",
        url:"newbook"

    }]
    
    document.body.style.backgroundImage=`url(${img})`
    document.body.style.backgroundSize = "cover";
document.body.style.backgroundPosition = "center";
    // document.body.style.backgroundColor="white"
    const cardlist = () => {
        return dispcards.map((item) => {
            return (
                <div class="card col-2 bg-dark text-light flex-wrap mx-5 my-5" style={{ width: "25rem" }}>
                    <Link to={`/${item.url}`}>
                        {/* {console.log(item.url)} */}
                    <img src="..." class="card-img-top" alt="Logo" />
                    <hr />
                    <div class="card-body fs-4">
                        <h5 class="card-title">{item.title}</h5>
                        <p class="card-text">Book Stat</p>
                        <a href="#" class="btn btn-primary">Go somewhere</a>
                    </div>
                </Link>
                </div>
            )
        })
    }
    return (
        <div>
            <Navbar display={false} />
            <div className="px-2  d-flex  justify-content-center " style={{backgroundColor: "rgba(0, 0, 0, 0.8)",height:"100vh"}}>
                <div className="row">
                    {cardlist()}

                </div>
            </div>
        </div>
    )
}
